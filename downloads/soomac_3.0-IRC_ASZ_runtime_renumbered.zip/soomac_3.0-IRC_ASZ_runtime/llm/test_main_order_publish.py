"""Offline publisher-contract tests; no ROS graph or robot commands are used."""
import copy
import importlib.util
import json
import sys
import types
from pathlib import Path
from unittest.mock import Mock

import pytest

from checkout_manager import OrderHandoffManager, OrderHandoffError
from main_order_payload import OrderOutbox, build_main_order


def burger(menu="cheese_burger", quantity=1, kind="single", **kwargs):
    item = dict(item_type="burger", menu=menu, quantity=quantity, type=kind,
                exclude=[], add_toppings=[])
    if kind == "set":
        item.update(drink="coke", drink_size="small", side="french_fries")
    item.update(kwargs)
    return item


def state(*items):
    return dict(intent="confirm", items=list(items))


def queued(manager):
    return [json.loads(p.read_text()) for p in sorted(
        manager.order_outbox.pending.glob("order_*.json"),
        key=lambda p: int(p.stem.removeprefix("order_")))]


def test_summary_merges_modifiers_and_set_options_but_charges_everything(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    original = state(
        burger(kind="set", add_toppings=["bacon"]),
        burger(quantity=2, kind="set", drink="iced_coffee", drink_size="large",
               side="cheese_stick", exclude=["onion"]),
        burger("chicken_burger", 2),
        burger(),
        dict(item_type="drink", drink="fanta", drink_size="small", quantity=1),
        dict(item_type="drink", drink="fanta", drink_size="small", quantity=2),
        dict(item_type="drink", drink="fanta", drink_size="large", quantity=1),
        dict(item_type="side", side="cheese_stick", quantity=2),
        dict(item_type="side", side="cheese_stick", quantity=1),
    )
    before = copy.deepcopy(original)
    handoff = manager.create_counter_handoff(original)
    assert original == before
    assert handoff["menu"][0]["add_toppings"] == ["bacon"]
    assert queued(manager) == [{
        "order_no": 1,
        "menu": "치즈버거 세트 3개, 치킨버거 단품 2개, 치즈버거 단품 1개, 환타 스몰 3잔, 환타 라지 1잔, 치즈스틱 3개",
        "is_mcorder": False,
        "price": 8300 + 2 * 9200 + 2 * 4800 + 5000 + 3 * 2000 + 2700 + 3 * 2500,
    }]


def test_counter_mobile_share_sequence_and_resume_after_restart(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    manager.create_counter_handoff(state(burger()))
    manager.create_mobile_handoff(65)
    assert queued(manager)[1] == {
        "order_no": 2, "menu": "맥오더 65번", "is_mcorder": True, "price": 0}
    restarted = OrderHandoffManager(tmp_path)
    assert restarted.create_counter_handoff(state(burger()))["order_id"] == 3


def test_old_handoffs_are_not_replayed(tmp_path):
    (tmp_path / "handoff_12.json").write_text('{"old": true}')
    manager = OrderHandoffManager(tmp_path)
    assert manager.order_outbox.next_pending() is None
    assert manager.create_mobile_handoff(99)["order_id"] == 13


def test_sent_is_not_requeued_and_number_survives_handoff_cleanup(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    handoff = manager.create_mobile_handoff(7)
    manager.order_outbox.mark_sent(manager.order_outbox.next_pending())
    manager.order_outbox.enqueue(build_main_order(handoff))
    assert queued(manager) == []
    (tmp_path / "handoff_1.json").unlink()
    assert OrderHandoffManager(tmp_path).next_order_id() == 2


@pytest.mark.parametrize("intent", ["order", "cancel", "unknown"])
def test_unconfirmed_orders_never_enter_outbox(tmp_path, intent):
    manager = OrderHandoffManager(tmp_path)
    order = state(burger())
    order["intent"] = intent
    with pytest.raises(OrderHandoffError):
        manager.create_counter_handoff(order)
    assert queued(manager) == []


@pytest.mark.parametrize("order", [state(), state(burger(quantity=0)),
                                   state(burger(kind="set", drink=None))])
def test_incomplete_orders_never_enter_outbox(tmp_path, order):
    manager = OrderHandoffManager(tmp_path)
    with pytest.raises(OrderHandoffError):
        manager.create_counter_handoff(order)
    assert queued(manager) == []


def test_queue_write_failure_does_not_report_success(tmp_path, monkeypatch):
    manager = OrderHandoffManager(tmp_path)
    monkeypatch.setattr(manager.order_outbox, "enqueue", Mock(side_effect=OSError("disk full")))
    with pytest.raises(OrderHandoffError, match="disk full"):
        manager.create_counter_handoff(state(burger()))
    assert manager.last_handoff is None


def test_outbox_fifo_numeric_and_conflicting_number_rejected(tmp_path):
    box = OrderOutbox(tmp_path)
    for number in [10, 2, 1]:
        box.enqueue(dict(order_no=number, menu="맥오더 12번", is_mcorder=True, price=0))
    for number in [1, 2, 10]:
        assert box.next_pending().name == f"order_{number}.json"
        box.mark_sent(box.next_pending())
    with pytest.raises(ValueError, match="Conflicting"):
        box.enqueue(dict(order_no=1, menu="맥오더 13번", is_mcorder=True, price=0))


@pytest.fixture
def ros_module(monkeypatch):
    """Use real publisher code with ROS bindings replaced, without ROS installed."""
    modules = {name: types.ModuleType(name) for name in (
        "rclpy", "rclpy.node", "rclpy.duration", "rclpy.executors", "rclpy.qos",
        "std_msgs", "std_msgs.msg")}
    modules["rclpy.node"].Node = object
    modules["rclpy.duration"].Duration = lambda **kwargs: kwargs
    modules["rclpy.executors"].ExternalShutdownException = type("Shutdown", (Exception,), {})
    modules["rclpy.qos"].QoSProfile = lambda **kwargs: kwargs
    modules["rclpy.qos"].ReliabilityPolicy = types.SimpleNamespace(RELIABLE=1)
    modules["rclpy.qos"].DurabilityPolicy = types.SimpleNamespace(VOLATILE=0)
    modules["std_msgs.msg"].String = lambda **kwargs: types.SimpleNamespace(**kwargs)
    for name, module in modules.items():
        monkeypatch.setitem(sys.modules, name, module)
    import main_order_payload
    spec = importlib.util.spec_from_file_location(
        "isolated_order_publisher", Path(main_order_payload.__file__).with_name("order_result_publisher.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def publisher(ros_module, box):
    node = ros_module.OrderResultPublisher.__new__(ros_module.OrderResultPublisher)
    node.outbox = box
    node.target_name = "drive_thru_main"
    node._inflight = None
    node._last_error = None
    node._waiting = False
    node.publisher_ = Mock(topic_name="/order")
    node.publisher_.get_subscription_count.return_value = 1
    node.publisher_.wait_for_all_acked.return_value = True
    node.get_subscriptions_info_by_topic = Mock(return_value=[
        types.SimpleNamespace(node_name="drive_thru_main", topic_type="std_msgs/msg/String")])
    node.get_logger = Mock(return_value=Mock())
    return node


def test_ros_waits_for_main_not_echo_then_publishes_json_once(tmp_path, ros_module):
    manager = OrderHandoffManager(tmp_path)
    manager.create_counter_handoff(state(burger()))
    expected = queued(manager)[0]
    node = publisher(ros_module, manager.order_outbox)
    node.get_subscriptions_info_by_topic.return_value = [
        types.SimpleNamespace(node_name="_ros2cli_echo", topic_type="std_msgs/msg/String")]
    node.publish_pending()
    node.publisher_.publish.assert_not_called()
    assert queued(manager) == [expected]
    node.get_subscriptions_info_by_topic.return_value[0].node_name = "drive_thru_main"
    node.publish_pending()
    node.publish_pending()
    node.publisher_.publish.assert_called_once()
    assert json.loads(node.publisher_.publish.call_args.args[0].data) == expected
    assert queued(manager) == []
    restarted = publisher(ros_module, OrderOutbox(manager.order_outbox.directory))
    restarted.publish_pending()
    restarted.publisher_.publish.assert_not_called()


def test_ros_ack_timeout_does_not_republish_each_tick(tmp_path, ros_module):
    manager = OrderHandoffManager(tmp_path)
    manager.create_mobile_handoff(65)
    node = publisher(ros_module, manager.order_outbox)
    node.publisher_.wait_for_all_acked.side_effect = [False, False, True]
    node.publish_pending()
    node.publish_pending()
    assert len(queued(manager)) == 1
    node.publish_pending()
    assert queued(manager) == []
    node.publisher_.publish.assert_called_once()


def test_ros_publish_failure_keeps_pending(tmp_path, ros_module):
    manager = OrderHandoffManager(tmp_path)
    manager.create_mobile_handoff(65)
    node = publisher(ros_module, manager.order_outbox)
    node.publisher_.publish.side_effect = RuntimeError("DDS unavailable")
    node.publish_pending()
    assert len(queued(manager)) == 1
    assert node._inflight is None
    node.publisher_.publish.side_effect = None
    node.publish_pending()
    assert queued(manager) == []


def test_ros_mark_sent_failure_retries_mark_without_republishing(tmp_path, ros_module, monkeypatch):
    manager = OrderHandoffManager(tmp_path)
    manager.create_mobile_handoff(65)
    node = publisher(ros_module, manager.order_outbox)
    real = node.outbox.mark_sent
    monkeypatch.setattr(node.outbox, "mark_sent", Mock(side_effect=OSError("read only")))
    node.publish_pending()
    assert node._inflight is not None
    monkeypatch.setattr(node.outbox, "mark_sent", real)
    node.publish_pending()
    node.publisher_.publish.assert_called_once()
    assert queued(manager) == []


def test_corrupt_head_does_not_silently_skip_to_next_customer(tmp_path, ros_module):
    manager = OrderHandoffManager(tmp_path)
    manager.create_mobile_handoff(65)
    manager.create_mobile_handoff(66)
    manager.order_outbox.next_pending().write_text("invalid JSON")
    node = publisher(ros_module, manager.order_outbox)
    node.publish_pending()
    node.publisher_.publish.assert_not_called()
    assert len(list(manager.order_outbox.pending.glob("*.json"))) == 2


@pytest.mark.parametrize("turns,expected_menu", [
    (["마무리할게요", "마무리할게요"], "치즈버거 단품 1개"),
    (["맥오더 65번", "네", "네"], "맥오더 65번"),
    (["맥오더 65번"], None),
    (["맥오더 65번", "맥오더 66번", "네"], "맥오더 66번"),
    (["치즈버거 얼마예요?"], None),
    (["/reset"], None),
])
def test_actual_app_finalization_only_once(tmp_path, monkeypatch, turns, expected_menu):
    import drive_thru_app as app
    from order_runtime_final import OrderStateManager
    from order_update_schema import OrderUpdate
    from runtime_worker import RuntimeWorker

    class RuntimeWithoutModel:
        def __init__(self):
            self.manager = OrderStateManager()
            self.manager.apply(OrderUpdate.model_validate({
                "intent": "order", "actions": [{"operation": "add", "item": {
                    k: v for k, v in burger().items() if k not in ("exclude", "add_toppings")}}]}))

        def process(self, text):
            raise AssertionError("These test orders must not need a model call")

    worker = RuntimeWorker(RuntimeWithoutModel)
    manager = OrderHandoffManager(tmp_path)
    session = app.VehicleSessionController(worker, stt_session=Mock())
    session.state = app.AppState.ORDERING
    session.vehicle_present = True
    monkeypatch.setattr(app, "RuntimeWorker", lambda *a, **kw: worker)
    monkeypatch.setattr(app, "OrderHandoffManager", lambda *a, **kw: manager)
    monkeypatch.setattr(app, "VehicleSessionController", lambda *a, **kw: session)
    for name in ("RosSTTUDPInput", "SpeechInputWorker", "STTSessionController",
                 "start_customer_ui_server", "stop_customer_ui_server", "soomac_say",
                 "ui_add_customer_message", "ui_set_voice_mode", "ui_set_order_items",
                 "ui_set_order_meta"):
        monkeypatch.setattr(app, name, Mock())
    def fake_router(text, **kwargs):
        from router_schema import RouterOutput
        assert text == "마무리할게요"
        return RouterOutput.model_validate({"acts": [{
            "family": "order_action", "subtype": "finalize", "speech_act": "request",
            "commitment": "explicit", "target_domain": "order",
            "reference": {"source": "current_order", "resolved": True, "line_ids": []},
            "resolution": "clear",
        }]})

    monkeypatch.setattr(app, "route_customer_utterance", fake_router)
    commands = iter([*turns, "/quit"])
    queue_sizes = []

    def next_input(*args):
        queue_sizes.append(len(queued(manager)))
        return next(commands)

    monkeypatch.setattr(app, "get_customer_input", next_input)
    monkeypatch.setattr(app, "get_control_input", next_input)
    try:
        app.reset_router_history()
        app.reset_modifier_context()
        app.main()
    finally:
        worker.stop()
    if expected_menu is None:
        assert queued(manager) == []
    else:
        assert len(queued(manager)) == 1
        assert queued(manager)[0]["menu"] == expected_menu
        assert session.state == app.AppState.WAITING_FOR_EXIT
    if turns[0].startswith("맥오더"):
        assert queue_sizes[1] == 0  # Reading a pickup number is not confirmation.
