"""Cancellation keeps displayed item numbers and future references consecutive."""
import copy

import pytest

from order_runtime_final import OrderStateManager, RecoverableOrderError
from order_update_schema import OrderUpdate


def apply(manager, *actions):
    manager.apply(OrderUpdate.model_validate({"intent": "order", "actions": list(actions)}))


def add(menu, **kwargs):
    return {"operation": "add", "item": {"item_type": "burger", "menu": menu,
            "type": "single", "quantity": 1, **kwargs}}


def remove(number):
    return {"operation": "remove", "target": {"line_id": number}}


def ids(manager):
    return [item["line_id"] for item in manager.state["items"]]


@pytest.fixture
def manager():
    manager = OrderStateManager()
    apply(manager, *(add(menu) for menu in (
        "cheese_burger", "chicken_burger", "shrimp_burger", "bulgogi_burger")),
        {"operation": "add", "item": {"item_type": "drink", "drink": "fanta",
                                      "drink_size": "small", "quantity": 1}})
    return manager


def test_remove_middle_relabels_remaining_items_and_terminal(manager, capsys):
    import drive_thru_app as app
    apply(manager, remove(3))
    assert ids(manager) == [1, 2, 3, 4]
    assert [item["menu"] for item in manager.state["items"]] == [
        "cheese_burger", "chicken_burger", "bulgogi_burger", None]
    app.show_current_order(manager.state)
    output = capsys.readouterr().out
    assert "3. 불고기버거" in output and "4. 환타" in output
    assert "5. " not in output


def test_next_number_request_modifies_new_number(manager):
    import drive_thru_app as app
    apply(manager, remove(3))
    app.reset_modifier_context()
    flow = app.unified_modifier_flow("3번에 베이컨 추가해주세요", manager.state)
    assert flow["kind"] == "apply"
    manager.apply(OrderUpdate.model_validate(flow["update"]))
    assert manager.state["items"][2]["menu"] == "bulgogi_burger"
    assert manager.state["items"][2]["add_toppings"] == ["bacon"]
    apply(manager, remove(3))
    assert ids(manager) == [1, 2, 3]
    assert manager.state["items"][2]["drink"] == "fanta"


def test_multiple_removals_keep_original_targets_until_batch_finishes(manager):
    apply(manager, remove(3), remove(4))
    assert ids(manager) == [1, 2, 3]
    assert manager.state["items"][-1]["drink"] == "fanta"


def test_remove_and_modify_batch_updates_original_four_then_remaps_selection(manager):
    apply(manager, remove(1), {"operation": "modify", "target": {"line_id": 4},
                               "toppings_add": ["bacon"]})
    assert manager.state["items"][2]["menu"] == "bulgogi_burger"
    assert manager.state["items"][2]["add_toppings"] == ["bacon"]
    assert manager.last_selected_ids == [3]


def test_add_after_delete_uses_next_display_number(manager):
    apply(manager, remove(3))
    apply(manager, add("shrimp_burger"))
    assert ids(manager) == [1, 2, 3, 4, 5]
    assert manager.state["items"][-1]["menu"] == "shrimp_burger"


def test_failed_batch_restores_numbers_and_all_context(manager):
    before = copy.deepcopy(manager.__dict__)
    with pytest.raises(RecoverableOrderError):
        apply(manager, remove(3), remove(99))
    assert manager.__dict__ == before


def test_quantity_reduction_and_full_removal_restart_at_one():
    manager = OrderStateManager()
    apply(manager, add("cheese_burger", quantity=5))
    apply(manager, {"operation": "adjust_quantity", "target": {"line_id": 3},
                    "quantity_delta": -2})
    assert ids(manager) == [1, 2, 3]
    apply(manager, {"operation": "remove", "target": {"menu": "cheese_burger"},
                    "apply_to_all": True})
    assert ids(manager) == []
    assert manager.option_groups == {} and manager.last_selected_ids == []
    apply(manager, add("chicken_burger"))
    assert ids(manager) == [1]


def test_pending_option_and_group_follow_their_items_after_renumber():
    manager = OrderStateManager()
    apply(manager, add("chicken_burger"), add("cheese_burger", type="set", quantity=3))
    assert manager.pending == (2, "drink")
    apply(manager, remove(1))
    assert ids(manager) == [1, 2, 3]
    assert manager.pending == (1, "drink")
    assert manager.option_group_for(1) == [1, 2, 3]
    apply(manager, remove(2))
    assert manager.option_group_for(1) == [1, 2]
    assert manager.pending == (1, "drink")


def test_summary_total_and_customer_sequence_are_independent(manager, tmp_path):
    from checkout_manager import OrderHandoffManager
    from main_order_payload import build_main_order
    apply(manager, remove(3))
    manager.apply(OrderUpdate.model_validate({"intent": "confirm", "actions": []}))
    checkout = OrderHandoffManager(tmp_path)
    first = build_main_order(checkout.create_counter_handoff(manager.state))
    assert first["order_no"] == 1
    assert first["price"] == 5000 + 4800 + 4500 + 2000
    assert "새우" not in first["menu"]
    assert build_main_order(checkout.create_mobile_handoff(58))["order_no"] == 2
