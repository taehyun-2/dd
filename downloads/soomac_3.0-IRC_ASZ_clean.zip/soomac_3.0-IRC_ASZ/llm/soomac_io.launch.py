#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import ExecuteProcess


def generate_launch_description():

    stt_bridge = ExecuteProcess(
        cmd=[
            "python3",
            "/home/soomac/soomac_3.0-IRC_ASZ/llm/ros_stt_udp_bridge.py",
        ],
        output="screen",
    )

    tts_publisher = ExecuteProcess(
        cmd=[
            "python3",
            "/home/soomac/soomac_3.0-IRC_ASZ/llm/tts_text_publisher.py",
        ],
        output="screen",
    )

    return LaunchDescription([
        stt_bridge,
        tts_publisher,
    ])
