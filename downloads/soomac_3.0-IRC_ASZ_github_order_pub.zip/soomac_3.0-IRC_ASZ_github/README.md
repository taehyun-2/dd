# SOOMAC 3.0 — IRC Manipulator Drive-Thru

주문 확정 결과를 메인 노드 `/order`로 발행하는 기능을 추가했습니다.
[ROS_ORDER_PUB_KO.md](ROS_ORDER_PUB_KO.md)의 실행 방법과 메인 노드 맥오더 발화 패치를 확인하세요.


동국대학교 수맥(SOOMAC) IRC 매니퓰레이터 대회용 드라이브스루 로봇팔의 LLM/STT 실행 코드입니다.

이 저장소는 **실행·연동 코드 중심**으로 정리한 버전입니다. 원본 학습 JSONL, 회귀 테스트, 평가 결과 및 기존 모델 가중치는 포함하지 않습니다.

## 구성

- `llm/drive_thru_app.py`: 드라이브스루 주문 앱
- `llm/order_runtime_final.py`, `llm/router_*.py`: 주문 상태 및 Router
- `llm/checkout_manager.py`, `llm/menu_knowledge.py`: 가격/주문 정보
- `llm/ui/`: 고객·직원 화면
- `llm/qwen_stt_ros_node.py`, `llm/ros_stt_udp_bridge.py`: ROS2/STT 연동
- `llm/tts_text_publisher.py`: TTS 출력 연동
- `stt/qwen_live_ver_3.py`, `stt/stt_clova_ver_7.py`: STT 실행 스크립트
- `stt/nest.proto`: CLOVA STT용 protobuf 명세

## 실행 참고

1. Ubuntu/Python 환경과 CUDA 호환 vLLM을 준비합니다. 기본 Python 패키지는 `llm/requirements.txt`를 참고하세요.
2. **V14 병합 모델은 GitHub에 포함되어 있지 않습니다.** 로컬에 별도로 준비해야 합니다.
3. `llm/start_vllm.sh`에서 모델 경로를 사용 중인 컴퓨터에 맞게 확인한 뒤 vLLM을 실행합니다.
4. `llm/start_app.sh`는 자기 폴더로 이동한 뒤 앱을 실행합니다. `~/drive_thru_venv` 가상환경이 있는지 확인하세요.
5. CLOVA STT를 사용할 경우 [`stt/README.md`](stt/README.md)에 따라 protobuf 파일을 생성하고, `stt/env.sh.example`을 참고하여 로컬 비밀 키를 설정합니다. `env.sh`는 Git에 올리지 마세요.

자세한 내용은 [`llm/README.md`](llm/README.md)를 참고하세요.

> `start_app.sh`와 `soomac_io.launch.py`는 파일 위치를 기준으로 프로젝트 경로를 찾습니다. 외부 가상환경(`~/drive_thru_venv`)과 모델 경로는 별도로 확인해야 합니다. 모델/환경은 ZIP에 포함하지 않습니다.

## 검토 및 실행 안내

[PACKAGE_REVIEW_KO.md](PACKAGE_REVIEW_KO.md)에 보완 사항, 검증 범위와 실행 방법을 정리했습니다.
