#!/usr/bin/env python3

import copy
import json
import os
import re
import subprocess
import sys
import time

from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent

DEFAULT_CASES = (
    ROOT
    / "regression_cases"
    / "app_regression_v1.json"
)

RESULT_DIR = (
    ROOT
    / "regression_results"
)


# ============================================================
# JSON EXTRACTION
# ============================================================

def extract_json_after_marker(
    text,
    marker,
):
    results = []

    decoder = json.JSONDecoder()

    start = 0

    while True:

        marker_pos = text.find(
            marker,
            start,
        )

        if marker_pos == -1:
            break

        json_pos = text.find(
            "{",
            marker_pos + len(marker),
        )

        if json_pos == -1:
            break

        try:
            value, length = decoder.raw_decode(
                text[json_pos:]
            )

            results.append(value)

            start = (
                json_pos
                + length
            )

        except json.JSONDecodeError:
            start = (
                marker_pos
                + len(marker)
            )

    return results


def extract_router_outputs(text):
    return extract_json_after_marker(
        text,
        "DEBUG : ROUTER",
    )


def extract_llm_updates(text):
    return extract_json_after_marker(
        text,
        "[ LLM UPDATE ]",
    )


def extract_verified_updates(text):
    return extract_json_after_marker(
        text,
        "[ VERIFIED UPDATE ]",
    )


def extract_state_commands(text):
    return extract_json_after_marker(
        text,
        "ORDER STATE:",
    )


def extract_staff_replies(text):
    return re.findall(
        r"^STAFF > (.+)$",
        text,
        flags=re.MULTILINE,
    )


def extract_fastpath_events(text):
    return re.findall(
        r"^\[SYSTEM\] "
        r"\[(FAST PATH(?: FALLBACK)?)\] "
        r"(.+)$",
        text,
        flags=re.MULTILINE,
    )


def extract_router_runtime_events(text):
    return re.findall(
        r"^\[SYSTEM\] "
        r"\[ROUTER->RUNTIME\] "
        r"(.+)$",
        text,
        flags=re.MULTILINE,
    )


def extract_capability_events(text):
    return re.findall(
        r"^\[SYSTEM\] "
        r"\[CAPABILITY GUARD\] "
        r"(.+)$",
        text,
        flags=re.MULTILINE,
    )


# ============================================================
# EXPECTED STATE MATCHING
# ============================================================

def partial_match(
    actual,
    expected,
):
    if isinstance(
        expected,
        dict,
    ):
        if not isinstance(
            actual,
            dict,
        ):
            return False

        for key, value in expected.items():

            if key not in actual:
                return False

            if not partial_match(
                actual[key],
                value,
            ):
                return False

        return True

    if isinstance(
        expected,
        list,
    ):
        if not isinstance(
            actual,
            list,
        ):
            return False

        # 리스트는 순서보다 값 포함 여부를 본다.
        for expected_value in expected:

            if not any(
                partial_match(
                    actual_value,
                    expected_value,
                )
                for actual_value in actual
            ):
                return False

        return True

    return actual == expected


def evaluate_expected(
    expected,
    final_state,
    stdout,
):
    failures = []

    items = (
        final_state.get(
            "items",
            [],
        )
        if isinstance(
            final_state,
            dict,
        )
        else []
    )

    if "final_item_count" in expected:

        wanted = int(
            expected[
                "final_item_count"
            ]
        )

        actual = len(items)

        if actual != wanted:
            failures.append(
                {
                    "check": "final_item_count",
                    "expected": wanted,
                    "actual": actual,
                }
            )

    for wanted_item in expected.get(
        "final_items_contains",
        [],
    ):

        matched = any(
            partial_match(
                item,
                wanted_item,
            )
            for item in items
        )

        if not matched:
            failures.append(
                {
                    "check":
                        "final_items_contains",
                    "expected":
                        wanted_item,
                    "actual_items":
                        items,
                }
            )


    # ========================================================
    # STRICT ITEM MATCH
    # ========================================================
    #
    # final_items_contains는 리스트를 부분집합 방식으로 비교하므로
    # [] 같은 빈 리스트 검증에는 약하다.
    #
    # final_items_match는:
    #   - 지정한 key는 정확히 같은 값이어야 하고
    #   - 서로 다른 expected item은 서로 다른 actual item과 매칭
    #
    # 예:
    #   버거 2개 중 하나만 bacon
    # ========================================================

    strict_expected_items = expected.get(
        "final_items_match",
        [],
    )

    if strict_expected_items:

        unused_indexes = set(
            range(
                len(items)
            )
        )

        for wanted_item in strict_expected_items:

            matched_index = None

            for index in sorted(
                unused_indexes
            ):

                actual_item = items[index]

                ok = True

                for key, wanted_value in (
                    wanted_item.items()
                ):

                    if (
                        actual_item.get(key)
                        != wanted_value
                    ):
                        ok = False
                        break

                if ok:
                    matched_index = index
                    break

            if matched_index is None:

                failures.append(
                    {
                        "check":
                            "final_items_match",

                        "expected":
                            wanted_item,

                        "actual_items":
                            items,
                    }
                )

            else:

                unused_indexes.remove(
                    matched_index
                )


    if "final_intent" in expected:

        actual_intent = (
            final_state.get(
                "intent"
            )
            if isinstance(
                final_state,
                dict,
            )
            else None
        )

        if (
            actual_intent
            != expected["final_intent"]
        ):
            failures.append(
                {
                    "check": "final_intent",
                    "expected":
                        expected[
                            "final_intent"
                        ],
                    "actual":
                        actual_intent,
                }
            )

    for value in expected.get(
        "stdout_contains",
        [],
    ):

        if value not in stdout:
            failures.append(
                {
                    "check":
                        "stdout_contains",
                    "expected":
                        value,
                }
            )

    for value in expected.get(
        "stdout_not_contains",
        [],
    ):

        if value in stdout:
            failures.append(
                {
                    "check":
                        "stdout_not_contains",
                    "unexpected":
                        value,
                }
            )

    return failures


# ============================================================
# RUN ONE SCENARIO
# ============================================================

def run_scenario(
    scenario,
    *,
    timeout,
):
    scenario_id = scenario["id"]

    commands = [
        "/carin",
        "/debug",
    ]

    for utterance in scenario[
        "steps"
    ]:
        commands.append(
            utterance
        )

        # 매 문장 처리 후 실제 Runtime state를 저장한다.
        commands.append(
            "/state"
        )

    commands.append(
        "/quit"
    )

    stdin_text = (
        "\n".join(commands)
        + "\n"
    )

    env = os.environ.copy()

    env[
        "PYTHONUNBUFFERED"
    ] = "1"

    started = time.perf_counter()

    try:
        proc = subprocess.run(
            [
                sys.executable,
                "drive_thru_app.py",
            ],
            cwd=ROOT,
            input=stdin_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            timeout=timeout,
        )

        timed_out = False

    except subprocess.TimeoutExpired as e:

        elapsed = (
            time.perf_counter()
            - started
        )

        stdout = (
            e.stdout.decode(
                "utf-8",
                errors="replace",
            )
            if isinstance(
                e.stdout,
                bytes,
            )
            else (
                e.stdout
                or ""
            )
        )

        stderr = (
            e.stderr.decode(
                "utf-8",
                errors="replace",
            )
            if isinstance(
                e.stderr,
                bytes,
            )
            else (
                e.stderr
                or ""
            )
        )

        return {
            "id": scenario_id,
            "name":
                scenario.get(
                    "name"
                ),
            "steps":
                scenario["steps"],
            "status": "ERROR",
            "timed_out": True,
            "elapsed_sec":
                round(
                    elapsed,
                    3,
                ),
            "failures": [
                {
                    "check":
                        "scenario_timeout",
                    "timeout_sec":
                        timeout,
                }
            ],
            "stdout": stdout,
            "stderr": stderr,
        }

    elapsed = (
        time.perf_counter()
        - started
    )

    stdout = proc.stdout or ""
    stderr = proc.stderr or ""

    states = (
        extract_state_commands(
            stdout
        )
    )

    final_state = (
        copy.deepcopy(
            states[-1]
        )
        if states
        else {}
    )

    failures = (
        evaluate_expected(
            scenario.get(
                "expected",
                {},
            ),
            final_state,
            stdout,
        )
    )

    if proc.returncode != 0:
        failures.append(
            {
                "check":
                    "process_returncode",
                "actual":
                    proc.returncode,
            }
        )

    status = (
        "PASS"
        if not failures
        else "FAIL"
    )

    return {
        "id": scenario_id,
        "name":
            scenario.get(
                "name"
            ),
        "steps":
            scenario["steps"],

        "status":
            status,

        "returncode":
            proc.returncode,

        "timed_out":
            False,

        "elapsed_sec":
            round(
                elapsed,
                3,
            ),

        "failures":
            failures,

        "router_outputs":
            extract_router_outputs(
                stdout
            ),

        "fastpath_events": [
            {
                "kind": kind,
                "detail": detail,
            }
            for kind, detail
            in extract_fastpath_events(
                stdout
            )
        ],

        "router_runtime_events":
            extract_router_runtime_events(
                stdout
            ),

        "capability_guard_events":
            extract_capability_events(
                stdout
            ),

        "llm_updates":
            extract_llm_updates(
                stdout
            ),

        "verified_updates":
            extract_verified_updates(
                stdout
            ),

        "state_snapshots":
            states,

        "final_state":
            final_state,

        "staff_replies":
            extract_staff_replies(
                stdout
            ),

        "has_traceback":
            "Traceback" in stdout
            or "Traceback" in stderr,

        "has_internal_error":
            "[INTERNAL ERROR]"
            in stdout,

        # 원인 분석용으로 원본 로그도 반드시 보관
        "stdout":
            stdout,

        "stderr":
            stderr,
    }


# ============================================================
# MAIN
# ============================================================

def main():

    case_path = (
        Path(sys.argv[1])
        if len(sys.argv) >= 2
        else DEFAULT_CASES
    )

    timeout = 600

    if len(sys.argv) >= 3:
        timeout = int(
            sys.argv[2]
        )

    if not case_path.exists():
        raise SystemExit(
            f"case file not found: "
            f"{case_path}"
        )

    RESULT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    with case_path.open(
        "r",
        encoding="utf-8",
    ) as f:
        suite = json.load(f)

    scenarios = suite.get(
        "scenarios",
        [],
    )

    if not scenarios:
        raise SystemExit(
            "no scenarios"
        )

    timestamp = (
        datetime.now()
        .strftime(
            "%Y%m%d_%H%M%S"
        )
    )

    results = []

    print()
    print(
        f"SOOMAC REGRESSION "
        f"{len(scenarios)} CASES"
    )
    print()

    for index, scenario in enumerate(
        scenarios,
        start=1,
    ):

        print(
            f"[{index:02d}/"
            f"{len(scenarios):02d}] "
            f"{scenario['id']} "
            f"{scenario.get('name', '')}"
        )

        result = run_scenario(
            scenario,
            timeout=timeout,
        )

        results.append(
            result
        )

        print(
            f"    -> "
            f"{result['status']} "
            f"({result['elapsed_sec']}s)"
        )

        if result[
            "status"
        ] != "PASS":

            for failure in result.get(
                "failures",
                [],
            ):
                print(
                    "       ",
                    json.dumps(
                        failure,
                        ensure_ascii=False,
                    ),
                )

    pass_count = sum(
        result["status"]
        == "PASS"
        for result in results
    )

    fail_count = sum(
        result["status"]
        != "PASS"
        for result in results
    )

    output = {
        "suite":
            suite.get(
                "suite"
            ),

        "generated_at":
            datetime.now()
            .astimezone()
            .isoformat(),

        "environment": {
            "SOOMAC_LLM_URL":
                os.getenv(
                    "SOOMAC_LLM_URL"
                ),

            "SOOMAC_ROUTER_URL":
                os.getenv(
                    "SOOMAC_ROUTER_URL"
                ),

            "SOOMAC_ROUTER_MODEL":
                os.getenv(
                    "SOOMAC_ROUTER_MODEL"
                ),
        },

        "summary": {
            "total":
                len(results),
            "pass":
                pass_count,
            "fail":
                fail_count,
        },

        "results":
            results,
    }

    result_path = (
        RESULT_DIR
        / (
            "app_regression_"
            + timestamp
            + ".json"
        )
    )

    result_path.write_text(
        json.dumps(
            output,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print("=" * 68)
    print(
        f"PASS : {pass_count}"
    )
    print(
        f"FAIL : {fail_count}"
    )
    print(
        f"TOTAL: {len(results)}"
    )
    print("=" * 68)
    print()
    print(
        "RESULT JSON:"
    )
    print(
        result_path
    )


if __name__ == "__main__":
    main()
