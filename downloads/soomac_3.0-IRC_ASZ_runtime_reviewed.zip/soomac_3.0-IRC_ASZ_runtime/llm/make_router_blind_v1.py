#!/usr/bin/env python3

import json
from pathlib import Path

from router_schema import RouterOutput
from router_policy import evaluate_router_output


OUT = (
    Path(__file__).parent
    / "router_data/blind/router_blind_v1.jsonl"
)


def ref(
    source="none",
    resolved=False,
    value=None,
    line_ids=None,
):
    d = {
        "source": source,
        "resolved": resolved,
        "line_ids": line_ids or [],
    }

    if value is not None:
        d["value"] = value

    return d


def act(
    family,
    subtype,
    speech_act,
    commitment="none",
    *,
    target_domain=None,
    target=None,
    quantity=None,
    reference=None,
    resolution="clear",
):
    d = {
        "family": family,
        "subtype": subtype,
        "speech_act": speech_act,
        "commitment": commitment,
        "reference": (
            reference
            if reference is not None
            else ref()
        ),
        "resolution": resolution,
    }

    if target_domain is not None:
        d["target_domain"] = target_domain

    if target is not None:
        d["target"] = target

    if quantity is not None:
        d["quantity"] = quantity

    return d


def case(
    cid,
    utterance,
    router_act,
    policy,
    *,
    history=None,
    pending=None,
    items=None,
    tag,
):
    return {
        "id": cid,
        "tag": tag,
        "utterance": utterance,
        "context": {
            "history": history or [],
            "pending": pending,
            "order_state": {
                "items": items or [],
            },
        },
        "expected": {
            "acts": [router_act],
        },
        "expected_policy": [policy],
        "policy_reason": f"blind_{tag}",
    }


cases = []
n = 1


def add(
    utterance,
    router_act,
    policy,
    *,
    tag,
    history=None,
    pending=None,
    items=None,
):
    global n

    cases.append(
        case(
            f"B{n:03d}",
            utterance,
            router_act,
            policy,
            tag=tag,
            history=history,
            pending=pending,
            items=items,
        )
    )

    n += 1


# ============================================================
# 1. NEW DIRECT ORDER EXPRESSIONS - 12
# ============================================================

direct_orders = [
    ("불고기버거 하나 부탁드려요", "burger", "bulgogi_burger", 1),
    ("치킨버거 두 개 넣어주세요", "burger", "chicken_burger", 2),
    ("치즈버거 하나 할게요", "burger", "cheese_burger", 1),
    ("제로콜라 두 잔 주세요", "drink", "zero_coke", 2),
    ("사이다 하나 추가해주세요", "drink", "sprite", 1),
    ("콜라 세 잔 부탁해요", "drink", "coke", 3),
    ("감자튀김 두 개 주세요", "side", "french_fries", 2),
    ("치즈스틱 하나 추가할게요", "side", "cheese_stick", 1),
    ("불고기버거 두 개 주문할게요", "burger", "bulgogi_burger", 2),
    ("치킨버거 하나 주세요", "burger", "chicken_burger", 1),
    ("제로콜라 한 잔 추가요", "drink", "zero_coke", 1),
    ("감튀 하나 주세요", "side", "french_fries", 1),
]

for text, domain, target, qty in direct_orders:
    add(
        text,
        act(
            "order_action",
            "add",
            "request",
            "explicit",
            target_domain=domain,
            target=target,
            quantity=qty,
            reference=ref(
                "explicit",
                True,
                target,
            ),
        ),
        "execute_order",
        tag="direct_order",
    )


# ============================================================
# 2. NEW INFORMATION / READ-ONLY - 12
# ============================================================

info_cases = [
    ("버거 종류 좀 알려줘요", "menu", "burger", None),
    ("마실 건 어떤 게 있죠?", "menu", "drink", None),
    ("사이드 선택지 뭐 있어요?", "option", "side", None),
    ("치즈버거 가격이 어떻게 돼요?", "price", "burger", "cheese_burger"),
    ("제로콜라는 얼마예요?", "price", "drink", "zero_coke"),
    ("피클 빼는 거 가능하죠?", "possibility", "ingredient", "pickle"),
    ("우유 들어간 메뉴예요?", "allergen", "menu", "milk"),
    ("계란 들어가나요?", "allergen", "menu", "egg"),
    ("칼로리가 어느 정도예요?", "nutrition", "menu", None),
    ("당 함량은 어떻게 돼요?", "nutrition", "menu", "sugar"),
    ("결제는 카드로 하면 돼요?", "payment", "payment", None),
    ("주문 나오려면 좀 걸리나요?", "wait_time", "order", "current_order"),
]

for text, subtype, domain, target in info_cases:
    add(
        text,
        act(
            "info_query",
            subtype,
            "question",
            target_domain=domain,
            target=target,
            reference=(
                ref("explicit", True, target)
                if target not in {None, "current_order"}
                else ref(
                    "current_order",
                    True,
                    "current_order",
                )
                if target == "current_order"
                else ref()
            ),
            resolution=(
                "context_resolved"
                if target == "current_order"
                else "clear"
            ),
        ),
        "read_only",
        tag="info_query",
    )


# ============================================================
# 3. AMBIGUOUS / MUST NOT EXECUTE - 12
# ============================================================

ambiguous = [
    "저걸로요",
    "그거 할게요",
    "아까 거요",
    "그 메뉴로",
    "저쪽 걸로 주세요",
    "하나 빼주세요",
    "버거 하나 없애주세요",
    "그거 바꿔주세요",
    "아까 주문한 거 수정할게요",
    "그중 하나 취소요",
    "음... 그걸로 할까 모르겠네요",
    "아니 그거 말고... 잠깐만요",
]

for text in ambiguous:
    add(
        text,
        act(
            "clarify",
            "clarification",
            "request",
            "none",
            reference=ref(
                "deictic",
                False,
            ),
            resolution="ambiguous",
        ),
        "clarify",
        tag="ambiguity",
    )


# ============================================================
# 4. CURRENT ORDER MUTATION - 14
# ============================================================

items = [
    {
        "line_id": 1,
        "item_type": "burger",
        "menu": "bulgogi_burger",
        "type": "set",
        "drink": "coke",
        "drink_size": "medium",
        "side": "french_fries",
    },
    {
        "line_id": 2,
        "item_type": "burger",
        "menu": "cheese_burger",
        "type": "set",
        "drink": "zero_coke",
        "drink_size": "large",
        "side": "cheese_stick",
    },
    {
        "line_id": 3,
        "item_type": "burger",
        "menu": "chicken_burger",
        "type": "single",
    },
]

mutation_cases = [
    ("첫 번째 버거에서 피클만 빼줘요", "modify", "ingredient", "pickle", [1]),
    ("두 번째 메뉴 피클 제외해주세요", "modify", "ingredient", "pickle", [2]),
    ("세 번째 거 세트로 바꿔줘요", "modify", "burger", "set", [3]),
    ("첫 번째 메뉴 취소할게요", "remove", "burger", "bulgogi_burger", [1]),
    ("두 번째 주문 항목 삭제해주세요", "remove", "burger", "cheese_burger", [2]),
    ("세 번째 버거 취소요", "remove", "burger", "chicken_burger", [3]),
    ("제로콜라 들어간 버거에서 피클 빼줘요", "modify", "ingredient", "pickle", [2]),
    ("콜라 들어간 쪽 피클 빼주세요", "modify", "ingredient", "pickle", [1]),
]

for text, subtype, domain, target, lines in mutation_cases:
    add(
        text,
        act(
            "order_action",
            subtype,
            "request",
            "explicit",
            target_domain=domain,
            target=target,
            reference=ref(
                "current_order",
                True,
                target,
                lines,
            ),
            resolution="context_resolved",
        ),
        "execute_order",
        items=items,
        tag="current_order_mutation",
    )


current_queries = [
    ("제로콜라 들어간 주문이 몇 번째죠?", [2]),
    ("치킨버거가 몇 번째 항목이에요?", [3]),
    ("첫 번째 주문 뭐였죠?", [1]),
    ("두 번째 주문 내용 다시 알려줘요", [2]),
    ("세 번째 건 단품 맞아요?", [3]),
    ("지금 주문한 버거가 총 몇 개죠?", [1, 2, 3]),
]

for text, lines in current_queries:
    add(
        text,
        act(
            "info_query",
            "order_state",
            "question",
            target_domain="order",
            target="current_order",
            reference=ref(
                "current_order",
                True,
                "current_order",
                lines,
            ),
            resolution="context_resolved",
        ),
        "read_only",
        items=items,
        tag="current_order_query",
    )


# ============================================================
# 5. PREVIOUS RECOMMENDATION CONTEXT - 10
# ============================================================

rec_history = [
    {
        "role": "staff",
        "text": "치즈버거 세트를 추천드릴게요.",
    }
]

rec_cases = [
    ("그 추천 메뉴 하나 주세요", "order_action", "add", "execute_order"),
    ("아까 추천한 거 두 개 부탁해요", "order_action", "add", "execute_order"),
    ("그 메뉴 가격은 얼마죠?", "info_query", "price", "read_only"),
    ("추천해준 거 괜찮은 편이에요?", "recommendation", "general_recommendation", "read_only"),
    ("그 추천은 세트예요?", "info_query", "option", "read_only"),
    ("그거 주문할 수 있죠?", "info_query", "possibility", "read_only"),
    ("아까 추천한 메뉴 다시 말해줘요", "recommendation", "general_recommendation", "read_only"),
    ("추천한 거 말고 다른 걸로 추천해주세요", "recommendation", "general_recommendation", "read_only"),
    ("오 맛있겠는데요", "general_chat", "chat", "read_only"),
    ("좋아요", "no_action", "acknowledge", "no_action"),
]

for text, family, subtype, policy in rec_cases:
    target = (
        "cheese_burger"
        if family not in {"general_chat", "no_action"}
        else None
    )

    qty = (
        2
        if "두 개" in text
        else 1
        if family == "order_action"
        else None
    )

    add(
        text,
        act(
            family,
            subtype,
            (
                "request"
                if family in {"order_action", "recommendation"}
                else "question"
                if family == "info_query"
                else "statement"
                if family == "general_chat"
                else "acknowledgement"
            ),
            (
                "explicit"
                if family == "order_action"
                else "none"
            ),
            target_domain=(
                "burger"
                if target is not None
                else None
            ),
            target=target,
            quantity=qty,
            reference=ref(
                "previous_staff",
                True,
                (
                    "cheese_burger_set"
                    if target is not None
                    else "cheese_burger_set"
                ),
            ),
            resolution="context_resolved",
        ),
        policy,
        history=rec_history,
        tag="recommendation_context",
    )


# ============================================================
# 6. PENDING SELECTION - 10
# ============================================================

pending_items = [
    {
        "line_id": 1,
        "item_type": "burger",
        "menu": "bulgogi_burger",
        "type": "set",
    }
]

pending_cases = [
    (
        "drink",
        "음료 골라주세요.",
        "제로로 할게요",
        "drink",
        "zero_coke",
    ),
    (
        "drink",
        "음료 골라주세요.",
        "사이다로 주세요",
        "drink",
        "sprite",
    ),
    (
        "side",
        "사이드를 골라주세요.",
        "치즈스틱으로 할게요",
        "side",
        "cheese_stick",
    ),
    (
        "side",
        "사이드를 골라주세요.",
        "감튀로 주세요",
        "side",
        "french_fries",
    ),
    (
        "type",
        "단품이나 세트 중 골라주세요.",
        "세트로 할게요",
        "burger",
        "set",
    ),
    (
        "type",
        "단품이나 세트 중 골라주세요.",
        "단품으로요",
        "burger",
        "single",
    ),
]

for field, staff, text, domain, target in pending_cases:
    add(
        text,
        act(
            "order_action",
            "modify",
            "request",
            "explicit",
            target_domain=domain,
            target=target,
            reference=ref(
                "pending",
                True,
                target,
                [1],
            ),
            resolution="context_resolved",
        ),
        "execute_order",
        history=[
            {
                "role": "staff",
                "text": staff,
            }
        ],
        pending={
            "line_id": 1,
            "field": field,
        },
        items=pending_items,
        tag="pending",
    )


for field, staff in [
    ("drink", "음료 골라주세요."),
    ("side", "사이드를 골라주세요."),
    ("type", "단품이나 세트 중 골라주세요."),
    ("drink_size", "음료 사이즈 골라주세요."),
]:
    add(
        "음... 네",
        act(
            "clarify",
            "clarification",
            "affirm",
            "none",
            reference=ref(
                "pending",
                False,
            ),
            resolution="ambiguous",
        ),
        "clarify",
        history=[
            {
                "role": "staff",
                "text": staff,
            }
        ],
        pending={
            "line_id": 1,
            "field": field,
        },
        items=pending_items,
        tag="pending_ambiguous",
    )


# ============================================================
# 7. CONVERSATION / STAFF / CONTROL - 10
# ============================================================

control_cases = [
    ("잠시만 생각 좀 할게요", "conversation_control", "pause", "read_only"),
    ("잠깐 기다려주세요", "conversation_control", "pause", "read_only"),
    ("이제 계속 주문할게요", "conversation_control", "resume", "read_only"),
    ("다시 이어서 할게요", "conversation_control", "resume", "read_only"),
    ("직원분 좀 불러주실래요?", "staff_request", "staff_call", "event"),
    ("사람하고 이야기하고 싶어요", "staff_request", "staff_call", "event"),
    ("직원 호출은 취소해주세요", "staff_request", "staff_call_cancel", "event"),
    ("아 직원은 안 불러도 돼요", "staff_request", "staff_call_cancel", "event"),
    ("감사합니다 잘 알아듣네요", "general_chat", "chat", "read_only"),
    ("오늘 날씨 좋네요", "out_of_scope", "unsupported", "read_only"),
]

for text, family, subtype, policy in control_cases:
    add(
        text,
        act(
            family,
            subtype,
            (
                "request"
                if family in {
                    "conversation_control",
                    "staff_request",
                }
                else "statement"
            ),
            (
                "explicit"
                if family == "staff_request"
                else "none"
            ),
            target_domain=(
                "staff"
                if family == "staff_request"
                else "system"
                if family == "general_chat"
                else None
            ),
            target=(
                "staff"
                if family == "staff_request"
                else None
            ),
            reference=(
                ref(
                    "explicit",
                    True,
                    "staff",
                )
                if family == "staff_request"
                else ref()
            ),
        ),
        policy,
        tag="control",
    )


assert len(cases) == 80, len(cases)

OUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with OUT.open(
    "w",
    encoding="utf-8",
) as f:

    for c in cases:
        parsed = RouterOutput.model_validate(
            c["expected"]
        )

        policy = [
            d.status.value
            for d in evaluate_router_output(parsed)
        ]

        if policy != c["expected_policy"]:
            raise RuntimeError(
                f"{c['id']} expected_policy mismatch: "
                f"{policy} != {c['expected_policy']}"
            )

        f.write(
            json.dumps(
                c,
                ensure_ascii=False,
            )
            + "\n"
        )


print("[OK] Fresh Blind generated")
print("FILE :", OUT)
print("CASES:", len(cases))
