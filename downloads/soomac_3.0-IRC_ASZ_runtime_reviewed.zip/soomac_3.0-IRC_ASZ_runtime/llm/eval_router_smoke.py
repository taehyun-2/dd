#!/usr/bin/env python3

import json
from pathlib import Path

from router_client import route, RouterClientError
from router_policy import evaluate_router_output
from router_schema import RouterOutput


GOLD = (
    Path(__file__).parent
    / "router_data/gold/router_gold_smoke_v1.jsonl"
)


def dump_router(obj: RouterOutput):
    return obj.model_dump(
        mode="json",
        exclude_none=True,
    )


def main():
    rows = []

    with GOLD.open(
        encoding="utf-8"
    ) as f:
        for line in f:
            if line.strip():
                rows.append(
                    json.loads(line)
                )

    exact_ok = 0
    family_ok = 0
    subtype_ok = 0
    policy_ok = 0
    errors = 0

    failures = []

    for i, case in enumerate(
        rows,
        start=1,
    ):
        context = case["context"]

        try:
            actual = route(
                case["utterance"],
                history=context.get(
                    "history",
                    [],
                ),
                pending=context.get(
                    "pending",
                ),
                order_state=context.get(
                    "order_state",
                    {
                        "items": [],
                    },
                ),
                timeout=60.0,
            )

        except RouterClientError as e:
            errors += 1

            print(
                f"[{i:02d}/{len(rows)}] "
                f"ERROR {case['id']} "
                f"{case['utterance']!r}"
            )
            print(" ", e)

            failures.append(
                {
                    "id": case["id"],
                    "utterance":
                        case["utterance"],
                    "type": "client_error",
                    "error": str(e),
                }
            )

            continue

        expected = RouterOutput.model_validate(
            case["expected"]
        )

        actual_json = dump_router(actual)
        expected_json = dump_router(expected)

        exact = (
            actual_json
            == expected_json
        )

        actual_families = [
            a.family.value
            for a in actual.acts
        ]

        expected_families = [
            a.family.value
            for a in expected.acts
        ]

        actual_subtypes = [
            a.subtype.value
            for a in actual.acts
        ]

        expected_subtypes = [
            a.subtype.value
            for a in expected.acts
        ]

        family_match = (
            actual_families
            == expected_families
        )

        subtype_match = (
            actual_subtypes
            == expected_subtypes
        )

        decisions = evaluate_router_output(
            actual
        )

        actual_policy = [
            d.status.value
            for d in decisions
        ]

        expected_policy = (
            case["expected_policy"]
        )

        policy_match = (
            actual_policy
            == expected_policy
        )

        exact_ok += int(exact)
        family_ok += int(family_match)
        subtype_ok += int(subtype_match)
        policy_ok += int(policy_match)

        mark = (
            "PASS"
            if exact
            else "MISS"
        )

        print(
            f"[{i:02d}/{len(rows)}] "
            f"{mark} "
            f"{case['id']} "
            f"{case['utterance']!r}"
        )

        if not exact:
            print(
                "  expected:",
                json.dumps(
                    expected_json,
                    ensure_ascii=False,
                ),
            )

            print(
                "  actual  :",
                json.dumps(
                    actual_json,
                    ensure_ascii=False,
                ),
            )

            print(
                "  policy  :",
                actual_policy,
                "/ expected",
                expected_policy,
            )

            failures.append(
                {
                    "id": case["id"],
                    "utterance":
                        case["utterance"],
                    "type": "mismatch",
                    "expected":
                        expected_json,
                    "actual":
                        actual_json,
                    "expected_policy":
                        expected_policy,
                    "actual_policy":
                        actual_policy,
                }
            )

    total = len(rows)

    print()
    print("=" * 70)
    print("ROUTER SMOKE BASELINE")
    print("=" * 70)

    print(
        f"Exact RouterOutput : "
        f"{exact_ok}/{total}"
    )

    print(
        f"Family            : "
        f"{family_ok}/{total}"
    )

    print(
        f"Subtype           : "
        f"{subtype_ok}/{total}"
    )

    print(
        f"Policy            : "
        f"{policy_ok}/{total}"
    )

    print(
        f"Client errors     : "
        f"{errors}"
    )

    out = (
        Path(__file__).parent
        / "router_smoke_results.json"
    )

    out.write_text(
        json.dumps(
            failures,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print(
        "[RESULT FILE]",
        out,
    )


if __name__ == "__main__":
    main()
