#!/usr/bin/env python3

import argparse
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from router_client import route, RouterClientError
from router_policy import evaluate_router_output
from router_schema import RouterOutput


BASE_DIR = Path(__file__).parent
DEFAULT_GOLD_DIR = BASE_DIR / "router_data/gold"


def dump_router(obj: RouterOutput):
    return obj.model_dump(
        mode="json",
        exclude_none=True,
    )


def load_cases(file_arg=None):
    if file_arg:
        files = [Path(file_arg)]
    else:
        files = sorted(
            DEFAULT_GOLD_DIR.glob(
                "router_gold_*_v1.jsonl"
            )
        )

    if not files:
        raise SystemExit(
            "ERROR: gold file 없음"
        )

    rows = []
    seen = set()

    for gold_file in files:
        with gold_file.open(
            encoding="utf-8"
        ) as f:
            for line in f:
                if not line.strip():
                    continue

                case = json.loads(line)

                # Same utterance/context/answer duplicates
                # are evaluated only once.
                key = json.dumps(
                    {
                        "utterance":
                            case["utterance"],
                        "context":
                            case["context"],
                        "expected":
                            case["expected"],
                        "expected_policy":
                            case["expected_policy"],
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                )

                if key in seen:
                    continue

                seen.add(key)

                case["_source_file"] = (
                    gold_file.name
                )

                rows.append(case)

    return files, rows


def evaluate_one(index, case, timeout):
    context = case["context"]

    try:
        actual = route(
            case["utterance"],
            history=context.get(
                "history",
                [],
            ),
            pending=context.get(
                "pending",
            ),
            order_state=context.get(
                "order_state",
                {
                    "items": [],
                },
            ),
            timeout=timeout,
        )

    except Exception as e:
        return {
            "index": index,
            "case": case,
            "error": str(e),
        }

    expected = RouterOutput.model_validate(
        case["expected"]
    )

    actual_json = dump_router(
        actual
    )

    expected_json = dump_router(
        expected
    )

    exact = (
        actual_json
        == expected_json
    )

    actual_families = [
        act.family.value
        for act in actual.acts
    ]

    expected_families = [
        act.family.value
        for act in expected.acts
    ]

    family_match = (
        actual_families
        == expected_families
    )

    actual_subtypes = [
        act.subtype.value
        for act in actual.acts
    ]

    expected_subtypes = [
        act.subtype.value
        for act in expected.acts
    ]

    subtype_match = (
        actual_subtypes
        == expected_subtypes
    )

    decisions = evaluate_router_output(
        actual
    )

    actual_policy = [
        decision.status.value
        for decision in decisions
    ]

    expected_policy = (
        case["expected_policy"]
    )

    policy_match = (
        actual_policy
        == expected_policy
    )

    return {
        "index": index,
        "case": case,
        "error": None,
        "exact": exact,
        "family_match":
            family_match,
        "subtype_match":
            subtype_match,
        "policy_match":
            policy_match,
        "expected":
            expected_json,
        "actual":
            actual_json,
        "expected_policy":
            expected_policy,
        "actual_policy":
            actual_policy,
    }


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--file",
        default=None,
        help="Evaluate one gold JSONL file",
    )

    parser.add_argument(
        "--all",
        action="store_true",
        help="Evaluate all router gold files",
    )

    parser.add_argument(
        "--workers",
        type=int,
        default=8,
        help="Parallel requests (default: 8)",
    )

    parser.add_argument(
        "--timeout",
        type=float,
        default=90.0,
        help="Per-request timeout seconds",
    )

    parser.add_argument(
        "--verbose-misses",
        action="store_true",
        help="Print full mismatch details",
    )

    parser.add_argument(
        "--output",
        default="router_gold_results.json",
        help="Result JSON filename",
    )

    args = parser.parse_args()

    files, rows = load_cases(
        args.file
    )

    total = len(rows)

    print("=" * 70)
    print("ROUTER GOLD PARALLEL EVALUATION")
    print("=" * 70)
    print(
        f"Gold files : {len(files)}"
    )
    print(
        f"Unique     : {total}"
    )
    print(
        f"Workers    : {args.workers}"
    )
    print()

    exact_ok = 0
    family_ok = 0
    subtype_ok = 0
    policy_ok = 0
    errors = 0

    failures = []
    completed = 0

    with ThreadPoolExecutor(
        max_workers=args.workers
    ) as executor:

        futures = {
            executor.submit(
                evaluate_one,
                i,
                case,
                args.timeout,
            ): (i, case)
            for i, case
            in enumerate(
                rows,
                start=1,
            )
        }

        for future in as_completed(
            futures
        ):
            result = future.result()

            completed += 1

            case = result["case"]

            if result["error"]:
                errors += 1

                print(
                    f"[{completed:03d}/{total}] "
                    f"ERROR "
                    f"{case['id']} "
                    f"{case['utterance']!r}"
                )

                failures.append(
                    {
                        "id":
                            case["id"],
                        "source_file":
                            case[
                                "_source_file"
                            ],
                        "utterance":
                            case[
                                "utterance"
                            ],
                        "type":
                            "client_error",
                        "error":
                            result[
                                "error"
                            ],
                    }
                )

                continue

            exact_ok += int(
                result["exact"]
            )

            family_ok += int(
                result[
                    "family_match"
                ]
            )

            subtype_ok += int(
                result[
                    "subtype_match"
                ]
            )

            policy_ok += int(
                result[
                    "policy_match"
                ]
            )

            mark = (
                "PASS"
                if result["exact"]
                else "MISS"
            )

            print(
                f"[{completed:03d}/{total}] "
                f"{mark} "
                f"{case['id']} "
                f"{case['utterance']!r}"
            )

            if not result["exact"]:
                failure = {
                    "id":
                        case["id"],
                    "source_file":
                        case[
                            "_source_file"
                        ],
                    "utterance":
                        case[
                            "utterance"
                        ],
                    "type":
                        "mismatch",
                    "expected":
                        result[
                            "expected"
                        ],
                    "actual":
                        result[
                            "actual"
                        ],
                    "expected_policy":
                        result[
                            "expected_policy"
                        ],
                    "actual_policy":
                        result[
                            "actual_policy"
                        ],
                }

                failures.append(
                    failure
                )

                if args.verbose_misses:
                    print(
                        "  expected:",
                        json.dumps(
                            result[
                                "expected"
                            ],
                            ensure_ascii=False,
                        ),
                    )

                    print(
                        "  actual  :",
                        json.dumps(
                            result[
                                "actual"
                            ],
                            ensure_ascii=False,
                        ),
                    )

                    print(
                        "  policy  :",
                        result[
                            "actual_policy"
                        ],
                        "/ expected",
                        result[
                            "expected_policy"
                        ],
                    )

    print()
    print("=" * 70)
    print("ROUTER GOLD EVALUATION")
    print("=" * 70)

    print(
        f"Exact RouterOutput : "
        f"{exact_ok}/{total}"
    )

    print(
        f"Family             : "
        f"{family_ok}/{total}"
    )

    print(
        f"Subtype            : "
        f"{subtype_ok}/{total}"
    )

    print(
        f"Policy             : "
        f"{policy_ok}/{total}"
    )

    print(
        f"Client errors      : "
        f"{errors}"
    )

    out = (
        BASE_DIR
        / args.output
    )

    failures.sort(
        key=lambda x: (
            x["source_file"],
            x["id"],
        )
    )

    out.write_text(
        json.dumps(
            failures,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print(
        "[RESULT FILE]",
        out,
    )


if __name__ == "__main__":
    main()
