# soomac_3.0-IRC_ASZ
Repository for the Dongguk University robot arm team SOOMAC - IRC_Manipulator Competition

## 검토 및 실행 안내

[PACKAGE_REVIEW_KO.md](PACKAGE_REVIEW_KO.md)에 보완 사항, 검증 범위와 실행 방법을 정리했습니다.
