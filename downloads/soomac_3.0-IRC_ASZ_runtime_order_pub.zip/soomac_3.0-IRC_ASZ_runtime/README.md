# soomac_3.0-IRC_ASZ

주문 확정 결과를 메인 노드 `/order`로 발행하는 기능을 추가했습니다.
[ROS_ORDER_PUB_KO.md](ROS_ORDER_PUB_KO.md)의 실행 방법과 메인 노드 맥오더 발화 패치를 확인하세요.

Repository for the Dongguk University robot arm team SOOMAC - IRC_Manipulator Competition

## 검토 및 실행 안내

[PACKAGE_REVIEW_KO.md](PACKAGE_REVIEW_KO.md)에 보완 사항, 검증 범위와 실행 방법을 정리했습니다.
