"""Read the most recent confirmed orders for the staff board, without mutations."""

import copy
import json
import threading
import time
from pathlib import Path

from main_order_payload import build_main_order


HANDOFF_DIR = Path(__file__).resolve().parent / "runtime_data" / "handoffs"


class StaffOrderHistory:
    """All browsers see the same persisted handoffs, independently of drafts."""

    def __init__(self, directory=HANDOFF_DIR, refresh_interval=0.25):
        self.directory = Path(directory)
        self.refresh_interval = refresh_interval
        self.lock = threading.Lock()
        self._orders = []
        self._refresh_at = 0.0

    def snapshot(self):
        with self.lock:
            now = time.monotonic()
            if now >= self._refresh_at:
                self._orders = self._read_orders()
                self._refresh_at = now + self.refresh_interval
            return {"orders": copy.deepcopy(self._orders)}

    def _read_orders(self):
        candidates = []
        for path in self.directory.glob("handoff_*.json"):
            suffix = path.stem.removeprefix("handoff_")
            # Only canonical filenames written by OrderHandoffManager qualify.
            # Temp files, duplicate aliases and draft state files are excluded.
            if suffix.isascii() and suffix.isdecimal() and int(suffix) > 0:
                order_no = int(suffix)
                if path.name == f"handoff_{order_no}.json":
                    candidates.append((order_no, path))

        orders = []
        for order_no, path in sorted(candidates, reverse=True):
            try:
                handoff = json.loads(path.read_text(encoding="utf-8"))
                payload = build_main_order(handoff)
                if payload["order_no"] != order_no:
                    continue
            except (OSError, UnicodeError, ValueError, KeyError, TypeError):
                # A bad/deleted file must not hide other completed orders.
                continue
            payload["menu_lines"] = payload["menu"].split(", ")
            payload["mobile_order_id"] = (
                handoff["mobile_order_id"] if payload["is_mcorder"] else None
            )
            orders.append(payload)
            if len(orders) == 4:
                break
        return list(reversed(orders))
