/* Confirmed history comes from the server; a new vehicle never clears it. */
let lastOrders = "";

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function renderOrders(orders) {
    const signature = JSON.stringify(orders);
    if (signature === lastOrders) return;
    lastOrders = signature;

    const cards = orders.map(order => `
        <article class="order-card" data-order-no="${escapeHtml(order.order_no)}"
                 aria-label="주문번호 ${escapeHtml(order.order_no)}">
            <header class="order-head">
                <div class="order-label">주문번호</div>
                <div class="order-number">#${escapeHtml(order.order_no)}</div>
                <span class="order-mode">${order.is_mcorder ? "맥오더" : "일반 주문"}</span>
            </header>
            <ul class="menu-list">
                ${order.menu_lines.map(line => `<li class="menu-line">${escapeHtml(line)}</li>`).join("")}
            </ul>
            <footer class="order-total">
                <span>${order.is_mcorder ? "주문 방식" : "주문금액"}</span>
                <span class="total-price">${order.is_mcorder
                    ? "모바일 주문"
                    : `${Number(order.price).toLocaleString("ko-KR")}원`}</span>
            </footer>
        </article>
    `);
    while (cards.length < 4) {
        cards.push(`
            <div class="order-card empty-slot">
                <div class="empty-title">주문 대기</div>
                <div class="empty-note">확정된 주문이<br>여기에 표시됩니다.</div>
            </div>
        `);
    }
    document.getElementById("orderBoard").innerHTML = cards.join("");
    document.getElementById("orderCount").textContent = `${orders.length} / 4건`;
}

function renderStatus(state) {
    const status = document.getElementById("staffStatus");
    status.className = "status";
    if (state.staff_call_requested) {
        status.classList.add("alert");
        status.textContent = "🚨 직원 호출 요청";
    } else if (state.order_id != null) {
        status.textContent = state.order_mode === "mobile" ? "맥오더 접수 완료" : "주문 접수 완료";
    } else if (Array.isArray(state.items) && state.items.length) {
        status.textContent = "새 주문 입력 중";
    } else {
        status.textContent = "주문 대기 중";
    }
}

async function readJson(url) {
    const response = await fetch(url, {cache: "no-store"});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
}

async function syncStaff() {
    try {
        const [history, state] = await Promise.all([
            readJson("/api/staff/orders"),
            readJson("/api/state"),
        ]);
        renderOrders(history.orders);
        renderStatus(state);
    } catch (error) {
        // Keep the last confirmed board visible during a connection outage.
        const status = document.getElementById("staffStatus");
        status.className = "status offline";
        status.textContent = "연결 재시도 중";
    } finally {
        // Avoid overlapping requests that could paint an older response last.
        setTimeout(syncStaff, 500);
    }
}

renderOrders([]);
syncStaff();
