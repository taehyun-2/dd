"""Staff-board history checks using real checkout files, without ROS or a model."""

import json
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen

import pytest

from checkout_manager import OrderHandoffError, OrderHandoffManager
from staff_order_history import HANDOFF_DIR, StaffOrderHistory
import ui_runtime_bridge as ui


def burger(**changes):
    item = dict(item_type="burger", menu="cheese_burger", type="single",
                quantity=1, exclude=[], add_toppings=[])
    item.update(changes)
    return item


def confirmed(*items):
    return {"intent": "confirm", "items": list(items)}


def numbers(history):
    return [order["order_no"] for order in history.snapshot()["orders"]]


def test_window_moves_from_one_to_four_to_two_to_five(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    history = StaffOrderHistory(tmp_path, refresh_interval=0)
    assert numbers(history) == []
    for _ in range(4):
        manager.create_counter_handoff(confirmed(burger()))
    assert numbers(history) == [1, 2, 3, 4]
    manager.create_mobile_handoff(58)
    assert numbers(history) == [2, 3, 4, 5]
    for _ in range(7):
        manager.create_counter_handoff(confirmed(burger()))
    assert numbers(history) == [9, 10, 11, 12]


def test_vehicle_drafts_and_browser_or_process_restart_preserve_history(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    history = StaffOrderHistory(tmp_path, refresh_interval=0)
    manager.create_counter_handoff(confirmed(burger()))
    before = history.snapshot()
    store = ui.CustomerUIStore()
    store.set_order_meta(order_id=1, total_price=5000, order_mode="counter")
    store.reset_for_vehicle()
    store.set_items([burger(menu="shrimp_burger", quantity=2)])
    assert store.snapshot()["order_id"] is None
    assert history.snapshot() == before
    assert StaffOrderHistory(tmp_path).snapshot() == before
    with pytest.raises(OrderHandoffError):
        manager.create_counter_handoff({"intent": "order", "items": [burger()]})
    assert history.snapshot() == before


def test_summary_groups_menu_ignores_options_but_preserves_charged_total(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    order = manager.create_counter_handoff(confirmed(
        burger(type="set", drink="coke", drink_size="small", side="french_fries"),
        burger(type="set", drink="iced_coffee", drink_size="large", side="cheese_stick",
               add_toppings=["bacon"], quantity=2),
        dict(item_type="drink", drink="fanta", drink_size="small", quantity=2),
        dict(item_type="drink", drink="fanta", drink_size="large", quantity=1),
    ))
    displayed = StaffOrderHistory(tmp_path).snapshot()["orders"][0]
    assert displayed["menu_lines"] == ["치즈버거 세트 3개", "환타 스몰 2잔", "환타 라지 1잔"]
    assert displayed["price"] == order["total_price"] == 34200
    assert displayed["mobile_order_id"] is None


def test_mobile_never_inherits_previous_or_stale_draft_items(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    manager.create_counter_handoff(confirmed(burger(quantity=3)))
    manager.create_mobile_handoff(58)
    displayed = StaffOrderHistory(tmp_path).snapshot()["orders"][1]
    assert displayed == dict(order_no=2, menu="맥오더 58번", is_mcorder=True,
                             price=0, menu_lines=["맥오더 58번"], mobile_order_id=58)


def test_bad_files_and_duplicate_aliases_do_not_hide_real_orders(tmp_path):
    manager = OrderHandoffManager(tmp_path)
    for number in range(1, 6):
        manager.create_mobile_handoff(number)
    (tmp_path / "handoff_6.json").write_text("{unfinished", encoding="utf-8")
    (tmp_path / "handoff_7.json").write_text(json.dumps(dict(
        command="mobile_pickup", order_id=3, mobile_order_id=70)), encoding="utf-8")
    (tmp_path / "handoff_05.json").write_text((tmp_path / "handoff_5.json").read_text())
    (tmp_path / "handoff_8.json.tmp").write_text("{}")
    (tmp_path / "handoff_9.json").write_text('{"intent":"order","items":[]}')
    (tmp_path / "handoff_other.json").write_text("{}")
    history = StaffOrderHistory(tmp_path, refresh_interval=0)
    assert numbers(history) == [2, 3, 4, 5]
    assert numbers(history) == [2, 3, 4, 5]
    (tmp_path / "handoff_5.json").unlink()
    assert numbers(history) == [1, 2, 3, 4]


def test_cache_returns_isolated_snapshots_and_avoids_duplicate_file_reads(tmp_path, monkeypatch):
    manager = OrderHandoffManager(tmp_path)
    manager.create_mobile_handoff(58)
    history = StaffOrderHistory(tmp_path, refresh_interval=60)
    first = history.snapshot()
    monkeypatch.setattr(history, "_read_orders", lambda: pytest.fail("unnecessary read"))
    first["orders"][0]["menu_lines"].append("changed by caller")
    assert history.snapshot()["orders"][0]["menu_lines"] == ["맥오더 58번"]


def test_default_path_does_not_follow_terminal_working_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert StaffOrderHistory().directory == Path(ui.__file__).resolve().parent / "runtime_data/handoffs"
    assert StaffOrderHistory(tmp_path / "missing").snapshot() == {"orders": []}
    assert HANDOFF_DIR.is_absolute()


def test_http_history_shared_by_tabs_and_customer_state_contract_unchanged(tmp_path, monkeypatch):
    manager = OrderHandoffManager(tmp_path)
    manager.create_mobile_handoff(58)
    monkeypatch.setattr(ui, "STAFF_HISTORY", StaffOrderHistory(tmp_path, refresh_interval=0))
    monkeypatch.setattr(ui, "STORE", ui.CustomerUIStore())
    ui.STORE.request_staff_call()
    expected_state = ui.STORE.snapshot()
    server = ThreadingHTTPServer(("127.0.0.1", 0), ui.CustomerUIHandler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    base = f"http://127.0.0.1:{server.server_port}"
    try:
        with urlopen(base + "/api/staff/orders") as response:
            assert response.headers["Cache-Control"] == "no-store"
            first_tab = json.load(response)
        with urlopen(base + "/api/staff/orders?reload=1") as response:
            assert json.load(response) == first_tab
        with urlopen(base + "/api/state") as response:
            assert json.load(response) == expected_state
        ui.STORE.reset_for_vehicle()
        with urlopen(base + "/api/staff/orders") as response:
            assert json.load(response) == first_tab
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=2)
